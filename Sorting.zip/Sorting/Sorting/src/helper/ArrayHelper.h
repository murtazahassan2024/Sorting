#include <string>
using namespace std;

void copyArray(int source[], int destination[], int size);

void printArray(int array[], int size);
string arrayToString(int array[], int size);
