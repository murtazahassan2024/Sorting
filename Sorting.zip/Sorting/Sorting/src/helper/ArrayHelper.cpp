#include "ArrayHelper.h"
#include <iostream>
using namespace std;

void copyArray(int source[], int destination[], int size)
{
	for (int i = 0; i < size; i++)
	{
		destination[i] = source[i];
	}
}

void printArray(int array[], int size)
{
	cout << "[";
	for (int i = 0; i < size - 1; i++)
		cout << array[i] << ", ";
	cout << array[size - 1] << "]\n";
}

string arrayToString(int array[], int size)
{
	string results;
	results += "[";
	for (int i = 0; i < size - 1; i++)
		results += array[i] + ", ";
	results += array[size - 1] + "]\n";
	return results;
}
