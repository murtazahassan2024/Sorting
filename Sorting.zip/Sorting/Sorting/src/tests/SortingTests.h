#pragma once
#include "../sorting/Sorter.h"
#include "Timings.h"
#include <string>
using namespace std;

string runTests(vector<Sorter*> uuts);
void testTiming(vector<Sorter*> uuts);
