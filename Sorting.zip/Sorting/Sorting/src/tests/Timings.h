#include "../sorting/Sorter.h"
#include <iostream>
#include <typeinfo>
using namespace std;

class Timings
{
public:
	Sorter* sorter;
	double long randomized;
	double long sorted;
	double long inverseSorted;

	friend ostream& operator<<(ostream& strm, const Timings& t) {
		{
			return strm << "Time Testing - " << typeid(*t.sorter).name() << ".......\nTiming on Random: " << t.randomized <<
				"\nTiming on Sorted: " << t.sorted <<
				"\nTiming on Inverse Sorted: " << t.inverseSorted;
		}
	}
};
