#include "../helper/ArrayHelper.h"

class TestCase
{
public:
	int  size;
	int* original;
	int* expected;

	int* getTestCase()
	{
		int* test = new int[size];
		copyArray(original, test, size);
		return test;
	}
};
