#include <algorithm>
#include <iostream>
#include <ctime>
#include <chrono>
#include <typeinfo>
#include "../helper/TestHelper.h"
#include "../sorting/Sorter.h"
#include "Timings.h"
#include "TestCase.h"
using namespace std;

const int TEST_SIZE = 100;
const int TIME_SIZE = 20000;


int* createRandomTester(int size)
{
	int* tester = { new int[size] };
	for (int i = 0; i < size; i++)
	{
		tester[i] = rand();
	}
	return tester;
}


TestCase* setupRandomTest(int size)
{
	TestCase* test = new TestCase();
	test->size = size;
	test->original = createRandomTester(size);
	test->expected = new int[size];
	copyArray(test->original, test->expected, size);
	sort(test->expected, test->expected + size);
	return test;
}

string testSort(Sorter* sorter, TestCase* test)
{
	string results;
	int* testCase = test->getTestCase();
	sorter->sort(testCase, TEST_SIZE);

	for (int i = 1; i < TEST_SIZE; i++)
	{
		if (testCase[i] < testCase[i - 1])
		{
			results += typeid(sorter).name();
			results += " Sort Failed:";
			results += "Original : ";
			results += arrayToString(test->original, TEST_SIZE);
			results += "Your sort: ";
			results += arrayToString(testCase, TEST_SIZE);
			results += "Target   : ";
			results += arrayToString(test->expected, TEST_SIZE);
			break;
		}
	}
	return results;
}

double long timeSort(Sorter* sorter, int testMe[], int size)
{
	chrono::high_resolution_clock::time_point start = chrono::high_resolution_clock::now();
	sorter->sort(testMe, size);
	chrono::high_resolution_clock::time_point end = chrono::high_resolution_clock::now();
	chrono::duration<double, std::milli> span = end - start;
	return span.count();
}


TestCase* setupOrdered(int size)
{
	TestCase* test = new TestCase();
	test->size = size;
	int* sorted = new int[size];
	for (int i = 0; i < size; i++)
	{
		sorted[i] = i;
	}
	test->original = sorted;
	test->expected = new int[size];
	copyArray(test->original, test->expected, size);
	return test;
}

TestCase* setupInverse(int size)
{
	TestCase* test = new TestCase();
	test->size = size;
	int* inverse = new int[size];
	for (int i = 0; i < size; i++)
	{
		inverse[i] = size - i;
	}
	test->original = inverse;
	test->expected = new int[size];
	copyArray(test->original, test->expected, size);
	sort(test->expected, test->expected + size);
	return test;
}


Timings testTiming(Sorter* sorter, TestCase* randomTest, TestCase* ordered, TestCase* inverted)
{
	Timings timings;
	timings.sorter = sorter;
	int* random = randomTest->getTestCase();
	timings.randomized = timeSort(sorter, random, TIME_SIZE);

	int* sorted = ordered->getTestCase();
	timings.sorted = timeSort(sorter, sorted, TIME_SIZE);

	int* invert = inverted->getTestCase();
	timings.inverseSorted = timeSort(sorter, invert, TIME_SIZE);
	return timings;
}

string runTests(vector<Sorter*> uuts)
{
	string results;
	TestCase* testCase = setupRandomTest(TEST_SIZE);

	for (vector<Sorter*>::size_type i = 0; i < uuts.size(); i++)
	{
		results += testSort(uuts[i], testCase);
	}
	return results;
}

void testTiming(vector<Sorter*> uuts)
{
	TestCase* random  = setupRandomTest(TIME_SIZE);
	TestCase* ordered = setupOrdered(TIME_SIZE);
	TestCase* inverted = setupInverse(TIME_SIZE);
	for (vector<Sorter*>::size_type i = 0; i < uuts.size(); i++)
	{
		cout << testTiming(uuts[i], random, ordered, inverted) << endl;
	}
}
