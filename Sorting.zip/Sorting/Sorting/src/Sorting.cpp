#include <iostream>
#include <vector>
#include "sorting/Sorter.h"
#include "sorting/SelectionSort.h"
#include "sorting/BubbleSort.h"
#include "sorting/InsertionSort.h"
#include "sorting/MergeSort.h"
#include "sorting/ShellSort.h"
#include "sorting/QuickSort.h"
#include "sorting/Heapsort.h"
#include "tests/SortingTests.h"

using namespace std;

string test = "merge";
bool runTimingTests = false;
vector<Sorter*> uuts;

int main()
{

	if (test == "bubble")         uuts.push_back(new BubbleSort());
	else if (test == "insert")    uuts.push_back(new InsertionSort());
	else if (test == "selection") uuts.push_back(new SelectionSort());
	else if (test == "shell")     uuts.push_back(new ShellSort());
	else if (test == "merge")     uuts.push_back(new MergeSort());
	else if (test == "quick")     uuts.push_back(new QuickSort());
	else if (test == "heap")      uuts.push_back(new Heapsort());
	else
	{
		Sorter* all[] = { new BubbleSort(), new InsertionSort(), new SelectionSort() , new ShellSort(), new MergeSort(), new QuickSort(), new Heapsort()};
		for (auto s : all)
		{
			uuts.push_back(s);
		}
	}

	string results = runTests(uuts);

	if (results.size() == 0)
	{
		cout << "All Tests Passed!" << endl;

		if (runTimingTests)
		{
			testTiming(uuts);
		}
	} else
	{
		cout << results;
	}

}


void processParameters(int argc, char *argv[])
{
	if (argc == 1) {return;}
	test = string(argv[1]);
}
