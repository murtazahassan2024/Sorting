#pragma once
#include "Sorter.h"

class Heapsort : public Sorter
{
public:
	void sort(int* target, int size) override;
	void heapHelper(int target[], int i, int size);
};
