#include "InsertionSort.h"
#include <algorithm>

void InsertionSort::sort(int* target, int size)
{
	//std::sort(target, target + size);
	int temp;
	int i;
	int j;
	for(i=1; i<size; i++)
	{
		temp = target[i];
		j = i-1;

		while(j >= 0 && target[j] > temp)
		{
			target[j+1] = target[j];
			j=j-1;
		}
		target[j+1]=temp;
	}
}
