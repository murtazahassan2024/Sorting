#pragma once
#include "Sorter.h"

class BubbleSort : public Sorter
{
public:
	void sort(int* target, int size) override;
};

