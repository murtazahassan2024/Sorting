#pragma once
#include "Sorter.h"

class MergeSort : public Sorter
{
public:
	void sort(int* target, int size) override;

private:
	void merge(int arr[], int l, int m, int r);
	void sortHelper(int arr[], int l, int r);
};
