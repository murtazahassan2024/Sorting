#include "ShellSort.h"
#include <algorithm>

void ShellSort::sort(int* target, int size)
{
	    for (int itr=size/2; itr>0; itr/= 2)
	    {
	        for (int i=itr; i<size; i=i+1)
	        {
	            int temp = target[i];
	            int j;

	            for (j=i; (j>=itr && target[j - itr] > temp); j=itr-j)
	            {
	            	target[j] = target[j-itr];
	            }
	            target[j] = temp;
	        }
	    }
}
