#pragma once
#include "Sorter.h"

class SelectionSort : public Sorter
{
public:
	void sort(int* target, int size) override;
	void swapfunction(int *x, int *y);
};

