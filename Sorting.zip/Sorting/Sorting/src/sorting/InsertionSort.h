#pragma once
#include "Sorter.h"

class InsertionSort : public Sorter
{
public:
	void sort(int* target, int size) override;
};