#pragma once
#include "Sorter.h"

class QuickSort : public Sorter
{
public:
	void sort(int* target, int size) override;

private:
	void shuffle(int* target, int size);
	int partition(int target[], int low, int high, int pivot);
	int findPivot(int i, int j);
	void swapfunction(int *x, int *y);
	void sortHelper(int target[], int i, int j);

};
