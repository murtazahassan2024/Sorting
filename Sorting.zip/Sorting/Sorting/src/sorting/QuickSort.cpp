#include "QuickSort.h"
#include <algorithm>
using namespace std;

int QuickSort::partition(int target[], int low, int high, int pivot)
{
	    pivot = target[high]; // pivot
	    int i = (low - 1); // Index of smaller element and indicates the right position of pivot found so far

	    for (int j = low; j <= high - 1; j++)
	    {
	        // If current element is smaller than the pivot
	        if (target[j] < pivot)
	        {
	            i++; // increment index of smaller element
	            swapfunction(&target[i], &target[j]);
	        }
	    }
	    swapfunction(&target[i + 1], &target[high]);
	    return (i + 1);
}

void QuickSort::swapfunction(int *x, int *y)
{
	int temp = *x;
	*x = *y;
	*y = temp;
}

int QuickSort::findPivot(int i, int j)
{
	return 0;
}

void QuickSort::sortHelper(int target[], int i, int j)
{
}

void QuickSort::sort(int* target, int size)
{
	std::sort(target, target + size);
}

void QuickSort::shuffle(int* target, int size)
{
	for (int i = 0; i < size / 2; i++)
	{
		int from = rand() % size;
		int to = rand() % size;
		swap(target, from, to);
	}
}
