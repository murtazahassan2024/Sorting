#include "MergeSort.h"
#include <algorithm>

void MergeSort::merge(int arr[], int l, int m, int r)
{
	int left = m - l + 1;
	int right = r - m;
	int LEFT[left];
	int RIGHT[right];

	for (int i = 0; i < left; i = i + 1)
	{
		LEFT[i] = arr[l + i];
	}
	for (int j = 0; j < right; j = j + 1)
	{
		RIGHT[j] = arr[m + 1 + j];
	}

	int i = 0;
	int j = 0;
	int k = l;

	while (i < left && j < right)
	{
		if (LEFT[i] <= RIGHT[j])
		{
			arr[k] = LEFT[i];
			i = i + 1;
		}
		else
		{
			arr[k] = RIGHT[j];
			j = j + 1;
		}
		k = k + 1;
	}

	while (i < left)
	{
		arr[k] = LEFT[i];
		i = i + 1;
		k = k + 1;
	}

	while (j < right)
	{
		arr[k] = RIGHT[j];
		j = j + 1;
		k = k + 1;
	}
}

void MergeSort::sortHelper(int target[], int lo, int hi)
{
	if (lo < hi)
	{
		int mid = (lo + hi) / 2;
		sortHelper(target, lo, mid);
		sortHelper(target, mid + 1, hi);
		merge(target, lo, mid, hi);
	}
}

void MergeSort::sort(int* target, int size)
{
	sortHelper(target, 0, size-1);
}
