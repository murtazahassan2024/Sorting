#include "Heapsort.h"
#include <iostream>
#include <algorithm>
using namespace std;

void heapify(int target[], int size, int i)
{
    int largest = i;
    int left = 2*i + 1;
    int right = 2*i + 2;

    if(left < size && target[left] > target[largest])
    {
        largest = left;
    }
    if(right < size && target[right] > target[largest])
    {
    	largest = right;
    }

    if(largest != i)
    {
        swap(target[i], target[largest]);
        heapify(target, size, largest);
    }
}
void Heapsort::sort(int* target, int size)
{
	for (int i = size / 2 - 1; i >= 0; i--)
	{
		heapify(target, size, i);
	}

	for (int i=size-1; i>=0; i--)
	{
	    std::swap(target[0], target[i]);
		heapify(target, i, 0);
	}
}
