#include "BubbleSort.h"
#include <algorithm>
#include<bits/stdc++.h>

void BubbleSort::sort(int* target, int size)
{
	int temp;
	for (int i=0; i<size; i++)
	{
		for(int j = 0; j<size-1-i; j++)
		{
			if(target[j] > target[j+1])
			{
				temp = target[j];
				target[j] = target[j+1];
				target[j+1] = temp;
			}
		}
	}
}
