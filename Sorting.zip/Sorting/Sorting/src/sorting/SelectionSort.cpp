#include "SelectionSort.h"
#include <algorithm>
using namespace std;

void SelectionSort::sort(int* target, int size)
{
	int minimumindex;
	for (int i = 0; i < size-1; i++)
	{
		minimumindex = i;
		for (int j = i+1; j < size; j++)
		{
			if (target[j] < target[minimumindex])
			{
				minimumindex = j;
			}
		}
		swapfunction(&target[minimumindex], &target[i]);
	}
}

void SelectionSort::swapfunction(int *x, int *y)
{
	int temp = *x;
	*x = *y;
	*y = temp;
}

