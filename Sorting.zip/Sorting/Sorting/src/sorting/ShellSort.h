#pragma once
#include "Sorter.h"

class ShellSort : public Sorter
{
public:
	void sort(int* target, int size) override;
};

