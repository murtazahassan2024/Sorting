#pragma once

class Sorter
{
public:
	virtual void sort(int* target, int size) = 0;

protected:
	void swap(int* target, int from, int to)
	{
		int temp = target[from];
		target[from] = target[to];
		target[to] = temp;
	}

	bool less(int me, int other)
	{
		return me < other;
	}
};